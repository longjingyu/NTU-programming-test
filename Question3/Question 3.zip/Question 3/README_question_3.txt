//---------------Input file1: train_data.txt---------------//

1st column: x1
2nd column: x2
2nd column: x3

//---------------Input file2: train_truth.txt---------------//

1st column: y

//---------------Input file3: test_data.txt---------------//

1st column: x1
2nd column: x2
2nd column: x3

//---------------Output file1: test_predicted.txt---------------//

1st column: y


**NOTE**
Refer to "test_predicted_example.txt"





